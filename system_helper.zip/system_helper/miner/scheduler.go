package miner

import (
	"time"
)

type Scheduler struct {
	StartHour   int
	StartMinute int
	EndHour     int
	EndMinute   int
	Active      bool
}

func NewScheduler(startHour, startMinute, endHour, endMinute int) *Scheduler {
	return &Scheduler{
		StartHour:   startHour,
		StartMinute: startMinute,
		EndHour:     endHour,
		EndMinute:   endMinute,
		Active:      false,
	}
}

func (s *Scheduler) ShouldActivate(now time.Time) bool {
	currentHour := now.Hour()
	currentMinute := now.Minute()
	
	currentTotal := currentHour*60 + currentMinute
	startTotal := s.StartHour*60 + s.StartMinute
	endTotal := s.EndHour*60 + s.EndMinute
	
	if startTotal > endTotal {
		return currentTotal >= startTotal || currentTotal < endTotal
	}
	
	return currentTotal >= startTotal && currentTotal < endTotal
}

func (s *Scheduler) TimeUntilNextWindow(now time.Time) time.Duration {
	nextStart := time.Date(now.Year(), now.Month(), now.Day(), 
		s.StartHour, s.StartMinute, 0, 0, now.Location())
	
	if now.After(nextStart) {
		// ya pasó hoy entonces programar para mañana
		nextStart = nextStart.Add(24 * time.Hour)
	}
	
	return nextStart.Sub(now)
}

func (s *Scheduler) TimeRemaining(now time.Time) time.Duration {
	if !s.ShouldActivate(now) {
		return 0
	}
	
	currentHour := now.Hour()
	currentMinute := now.Minute()
	
	currentTotal := currentHour*60 + currentMinute
	endTotal := s.EndHour*60 + s.EndMinute
	
	if s.StartHour > s.EndHour && currentTotal < s.StartHour*60+s.StartMinute {
		endTotal += 24 * 60
		currentTotal += 24 * 60
	}
	
	remainingMinutes := endTotal - currentTotal
	if remainingMinutes < 0 {
		return 0
	}
	
	return time.Duration(remainingMinutes) * time.Minute
}

func (s *Scheduler) WaitUntilNextWindow() {
	for {
		now := time.Now()
		if s.ShouldActivate(now) {
			return
		}
		
		waitTime := s.TimeUntilNextWindow(now)
		if waitTime > 0 {
			// Esperar en chunks pequeños para responder
			maxWait := 30 * time.Second
			if waitTime > maxWait {
				waitTime = maxWait
			}
			time.Sleep(waitTime)
		} else {
			time.Sleep(30 * time.Second)
		}
	}
}
