package miner

import (
	"os"
	"runtime"
	"strconv"
	"strings"
	"syscall"
)

type CPUManager struct {
	TotalCores    int
	PhysicalCores int
	MaxUsage      float64 // 0.9 para 90%
}

func NewCPUManager(maxUsage float64) *CPUManager {
	return &CPUManager{
		TotalCores:    runtime.NumCPU(),
		PhysicalCores: getPhysicalCores(),
		MaxUsage:      maxUsage,
	}
}

func (c *CPUManager) GetOptimalThreads() int {
	availableCores := c.PhysicalCores - 1 //1 core libre
	if availableCores < 1 {
		availableCores = 1
	}
	
	optimal := int(float64(availableCores) * c.MaxUsage)
	
	load := c.GetSystemLoad()
	if load > 0.7 {
		optimal = optimal / 2
	}
	
	if optimal < 1 {
		optimal = 1
	}
	
	return optimal
}

func (c *CPUManager) GetSystemLoad() float64 {
	if runtime.GOOS != "linux" {
		return 0.0
	}
	
	data, err := os.ReadFile("/proc/loadavg")
	if err != nil {
		return 0.0
	}
	
	parts := strings.Fields(string(data))
	if len(parts) == 0 {
		return 0.0
	}
	
	load, _ := strconv.ParseFloat(parts[0], 64)
	return load / float64(c.TotalCores)
}

func (c *CPUManager) SetCPUAffinity(threadID int) {
	if runtime.GOOS != "linux" {
		return
	}
	
	core := threadID % c.TotalCores
	var mask syscall.CPUSet
	mask.Set(core)
	
	syscall.SchedSetaffinity(0, &mask)
}

func (c *CPUManager) SetLowPriority() {
	syscall.Setpriority(syscall.PRIO_PROCESS, 0, 10)
}

func (c *CPUManager) LimitCPUTime(maxPercent int) {
	if runtime.GOOS == "linux" {
		cgroupPath := "/sys/fs/cgroup/cpu/system_helper"
		os.MkdirAll(cgroupPath, 0755)
		
		period := 100000 // ms
		quota := int(float64(period) * float64(maxPercent) / 100.0)
		
		os.WriteFile(cgroupPath+"/cpu.cfs_period_us", []byte(strconv.Itoa(period)), 0644)
		os.WriteFile(cgroupPath+"/cpu.cfs_quota_us", []byte(strconv.Itoa(quota)), 0644)
		
		pid := strconv.Itoa(os.Getpid())
		os.WriteFile(cgroupPath+"/cgroup.procs", []byte(pid), 0644)
	}
}

func getPhysicalCores() int {
	if runtime.GOOS != "linux" {
		return runtime.NumCPU() / 2
	}
	
	data, err := os.ReadFile("/proc/cpuinfo")
	if err != nil {
		return runtime.NumCPU() / 2
	}
	
	content := string(data)
	physicalIDs := make(map[string]bool)
	
	lines := strings.Split(content, "\n")
	var currentID string
	
	for _, line := range lines {
		if strings.HasPrefix(line, "physical id") {
			parts := strings.Split(line, ":")
			if len(parts) > 1 {
				currentID = strings.TrimSpace(parts[1])
				physicalIDs[currentID] = true
			}
		}
	}
	
	if len(physicalIDs) > 0 {
		return len(physicalIDs)
	}
	
	return runtime.NumCPU() / 2
}
