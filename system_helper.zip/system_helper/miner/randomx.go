package miner

/*
#cgo CFLAGS: -I/usr/local/include -O3 -march=native -mtune=native
#cgo LDFLAGS: -L/usr/local/lib -lrandomx -lstdc++ -lm -lpthread
#include <randomx.h>
#include <stdlib.h>
*/
import "C"

import (
	"encoding/binary"
	"unsafe"
)

type RandomXEngine struct {
	vm    *C.randomx_vm
	cache *C.randomx_cache
}

type Work struct {
	Blob   []byte
	Target []byte
	JobID  string
	Height uint64
}

func NewRandomXEngine(key []byte) (*RandomXEngine, error) {
	cache := C.randomx_alloc_cache(C.RANDOMX_FLAG_DEFAULT)
	if cache == nil {
		return nil, ErrCacheAlloc
	}
	
	C.randomx_init_cache(cache, unsafe.Pointer(&key[0]), C.size_t(len(key)))
	
	vm := C.randomx_create_vm(C.RANDOMX_FLAG_DEFAULT, cache, nil)
	if vm == nil {
		C.randomx_release_cache(cache)
		return nil, ErrVMCreate
	}
	
	return &RandomXEngine{
		vm:    vm,
		cache: cache,
	}, nil
}

func (r *RandomXEngine) ProcessWork(work *Work) ([]byte, bool) {
	output := make([]byte, 32)
	
	// calcular hash
	C.randomx_calculate_hash(r.vm,
		unsafe.Pointer(&work.Blob[0]),
		C.size_t(len(work.Blob)),
		unsafe.Pointer(&output[0]))
	
	// Verificar contra target
	return output, r.checkHash(output, work.Target)
}

func (r *RandomXEngine) checkHash(hash, target []byte) bool {
	if len(hash) != 32 || len(target) != 32 {
		return false
	}
	
	for i := 31; i >= 0; i-- {
		if hash[i] < target[i] {
			return true
		}
		if hash[i] > target[i] {
			return false
		}
	}
	
	return true // hash == target
}

func (r *RandomXEngine) CalculateHashWithNonce(blob []byte, nonce uint32) []byte {
	if len(blob) >= 43 {
		binary.LittleEndian.PutUint32(blob[39:43], nonce)
	}
	
	output := make([]byte, 32)
	C.randomx_calculate_hash(r.vm,
		unsafe.Pointer(&blob[0]),
		C.size_t(len(blob)),
		unsafe.Pointer(&output[0]))
	
	return output
}

func (r *RandomXEngine) Destroy() {
	if r.vm != nil {
		C.randomx_destroy_vm(r.vm)
		r.vm = nil
	}
	if r.cache != nil {
		C.randomx_release_cache(r.cache)
		r.cache = nil
	}
}

func (r *RandomXEngine) Benchmark(iterations int) float64 {
	testData := make([]byte, 76)
	
	start := time.Now()
	for i := 0; i < iterations; i++ {
		binary.LittleEndian.PutUint32(testData[39:43], uint32(i))
		output := make([]byte, 32)
		C.randomx_calculate_hash(r.vm,
			unsafe.Pointer(&testData[0]),
			C.size_t(len(testData)),
			unsafe.Pointer(&output[0]))
	}
	
	elapsed := time.Since(start).Seconds()
	return float64(iterations) / elapsed
}

var (
	ErrCacheAlloc = errors.New("no se pudo asignar cache RandomX")
	ErrVMCreate   = errors.New("no se pudo crear VM RandomX")
)
