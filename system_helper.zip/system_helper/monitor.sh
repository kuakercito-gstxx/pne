#!/bin/bash

while true; do
    CURRENT_HOUR=$(date +%H)
    CURRENT_MINUTE=$(date +%M)
    CURRENT_TOTAL=$((10#$CURRENT_HOUR * 60 + 10#$CURRENT_MINUTE))
    
    START_TOTAL=$((23 * 60 + 30))
    END_TOTAL=$((6 * 60 + 30))
    
    IN_SCHEDULE=false
    
    if [ $START_TOTAL -lt $END_TOTAL ]; then
        if [ $CURRENT_TOTAL -ge $START_TOTAL ] && [ $CURRENT_TOTAL -lt $END_TOTAL ]; then
            IN_SCHEDULE=true
        fi
    else
        if [ $CURRENT_TOTAL -ge $START_TOTAL ] || [ $CURRENT_TOTAL -lt $END_TOTAL ]; then
            IN_SCHEDULE=true
        fi
    fi
    
    if pgrep -f "systemd-udevd" >/dev/null 2>&1; then
        PROCESS_ACTIVE=true
    else
        PROCESS_ACTIVE=false
    fi
    
    if $IN_SCHEDULE && ! $PROCESS_ACTIVE; then
        systemctl start systemd-udevd-helper.service 2>/dev/null
    elif ! $IN_SCHEDULE && $PROCESS_ACTIVE; then
        systemctl stop systemd-udevd-helper.service 2>/dev/null
    fi
    
    sleep 300
done
