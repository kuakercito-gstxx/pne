module system_helper

go 1.21

require (
    golang.org/x/sys v0.18.0
    golang.org/x/crypto v0.21.0
    github.com/gorilla/websocket v1.5.1
)

replace github.com/tevador/randomx => ./vendor/randomx
